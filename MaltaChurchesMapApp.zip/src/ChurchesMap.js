import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';

export default function ChurchesMap() {
  const churches = [
    {
      name: "St. John's Co-Cathedral",
      locality: "Valletta",
      category: "Cathedral",
      lat: 35.8997,
      lng: 14.5146,
      image: "https://upload.wikimedia.org/wikipedia/commons/1/1c/St_John%27s_Co-Cathedral.jpg",
      year: "1572",
      description: "Built by the Order of St. John, this cathedral is one of the finest examples of Baroque architecture in Europe."
    },
    {
      name: "Our Lady of Victories Church",
      locality: "Valletta",
      category: "Church",
      lat: 35.8987,
      lng: 14.5138,
      image: "https://upload.wikimedia.org/wikipedia/commons/6/64/Our_Lady_of_Victory_Church_Valletta.jpg",
      year: "1566",
      description: "The first building completed in Valletta, built to commemorate the victory at the Great Siege of 1565."
    }
  ];

  return (
    <div style={{ height: '100vh', width: '100%' }}>
      <MapContainer center={[35.8997, 14.5146]} zoom={15} style={{ height: '100%', width: '100%' }}>
        <TileLayer
          attribution='&copy; OpenStreetMap contributors'
          url='https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png'
        />
        {churches.map((church, idx) => (
          <Marker key={idx} position={[church.lat, church.lng]}>
            <Popup>
              <strong>{church.name}</strong><br />
              <img src={church.image} alt={church.name} style={{ width: '100px', marginTop: '5px' }} /><br />
              <em>{church.locality}</em><br />
              Year Built: {church.year}<br />
              {church.description}
            </Popup>
          </Marker>
        ))}
      </MapContainer>
    </div>
  );
}